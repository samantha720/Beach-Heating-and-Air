# Beach Heating & Air Vite Project

## Run locally
```bash
npm install
npm run dev
```

## Build for production
```bash
npm run build
```

## Preview production build
```bash
npm run preview
```

## Notes
- Main app file: `src/App.jsx`
- Main styles: `src/index.css`
- Update phone/email/content directly in `src/App.jsx`
- Replace placeholder before/after sections with real photos when ready
