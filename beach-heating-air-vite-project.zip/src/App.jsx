const reviews = [
  {
    name: "Sarah M.",
    text: "Fast response, honest pricing, and our new system works amazing. Super clean install.",
  },
  {
    name: "David R.",
    text: "They explained all our options clearly and got the install done fast. Highly recommend.",
  },
  {
    name: "Monica T.",
    text: "Professional from start to finish. Financing made it easy to move forward right away.",
  },
];

const plans = [
  {
    name: "Good",
    badge: "Budget Friendly",
    price: "$7.9k+",
    description:
      "Reliable comfort for homeowners who want a solid replacement at a value price.",
    features: [
      "Standard efficiency system",
      "1-year labor coverage",
      "Smart thermostat option",
    ],
  },
  {
    name: "Better",
    badge: "Most Popular",
    price: "$9.8k+",
    description: "The best mix of efficiency, comfort, and long-term value.",
    features: [
      "High-efficiency system",
      "Extended warranty",
      "Improved airflow and comfort",
    ],
    featured: true,
  },
  {
    name: "Best",
    badge: "Premium Comfort",
    price: "$12.5k+",
    description: "Top-tier comfort, energy savings, and premium protection.",
    features: [
      "Premium variable-speed system",
      "Best warranty package",
      "Indoor air quality upgrade",
    ],
  },
];

const services = [
  "Same-day HVAC installation",
  "AC and heating repair",
  "Preventive maintenance",
  "Ductwork improvements",
  "Thermostat upgrades",
  "Indoor air quality solutions",
];

const faqs = [
  {
    q: "Do you offer same-day install?",
    a: "Yes. When availability allows, we prioritize same-day replacements and urgent comfort issues.",
  },
  {
    q: "Do you offer financing?",
    a: "Yes. We can present monthly payment options and promotional financing for qualified homeowners.",
  },
  {
    q: "What areas do you serve?",
    a: "We serve Orange County and surrounding communities with fast, professional residential HVAC service.",
  },
];

function SectionTag({ children }) {
  return <div className="section-tag">{children}</div>;
}

function CTAButton({ href, children, secondary = false }) {
  return (
    <a href={href} className={secondary ? "btn btn-secondary" : "btn btn-primary"}>
      {children}
    </a>
  );
}

function CityPage({ city }) {
  return (
    <section className="city-page">
      <h2>HVAC Services in {city}, CA</h2>
      <p>
        Beach Heating & Air provides same-day HVAC installation, AC repair, heating service,
        and energy-efficient upgrades in {city}. We specialize in fast response times, clean
        installs, and long-term comfort solutions for Orange County homeowners.
      </p>
      <div className="city-grid">
        <div className="card">
          <h3>Services in {city}</h3>
          <ul className="plain-list">
            <li>Same-day HVAC installation</li>
            <li>AC repair and diagnostics</li>
            <li>Furnace and heating repair</li>
            <li>Ductwork and airflow improvements</li>
            <li>Smart thermostat installation</li>
          </ul>
        </div>
        <div className="card">
          <h3>FAQs</h3>
          <p><strong>How much does HVAC replacement cost in {city}?</strong></p>
          <p>Most systems range from $7,000-$12,000 depending on efficiency and home size.</p>
          <p><strong>Do you offer same-day service in {city}?</strong></p>
          <p>Yes, we prioritize same-day installs and urgent repairs when availability allows.</p>
        </div>
      </div>
      <div className="cta-banner small">
        <h3>Need HVAC help in {city}?</h3>
        <p>Call (949) 287-3618 for a free estimate.</p>
      </div>
    </section>
  );
}

export default function App() {
  return (
    <div className="site-shell">
      <header className="topbar">
        <div className="container topbar-inner">
          <div className="brand">
            <div className="brand-mark">B</div>
            <div>
              <div className="brand-title">Beach Heating & Air</div>
              <div className="brand-subtitle">Coastal Comfort Experts</div>
            </div>
          </div>

          <nav className="nav">
            <a href="#services">Services</a>
            <a href="#systems">Systems</a>
            <a href="#reviews">Reviews</a>
            <a href="#financing">Financing</a>
            <a href="#contact">Contact</a>
          </nav>

          <a href="tel:+19492873618" className="call-now">
            Call Now
          </a>
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="container hero-grid">
            <div>
              <div className="status-pill">
                <span className="status-dot" />
                Same-Day Install Available
              </div>
              <h1>Same-Day HVAC Service in Orange County</h1>
              <p className="hero-copy">
                Fast, clean, professional heating and air service with premium installation
                options, financing, and comfort solutions built for coastal homes.
              </p>
              <div className="hero-actions">
                <CTAButton href="#contact">Get Free Estimate</CTAButton>
                <CTAButton href="#systems" secondary>
                  View System Options
                </CTAButton>
              </div>

              <div className="stat-grid">
                <div className="stat-card">
                  <strong>24/7</strong>
                  <span>Priority Response</span>
                </div>
                <div className="stat-card">
                  <strong>5-Star</strong>
                  <span>Customer Care</span>
                </div>
                <div className="stat-card">
                  <strong>Flexible</strong>
                  <span>Financing Options</span>
                </div>
              </div>
            </div>

            <div className="hero-offer-wrap">
              <div className="hero-offer">
                <div className="offer-top">
                  <div>
                    <p className="eyebrow">Featured Offer</p>
                    <h2>Replace Now. Pay Over Time.</h2>
                    <p>
                      High-efficiency system upgrades with monthly payment options and honest
                      recommendations.
                    </p>
                  </div>
                  <div className="offer-price">
                    <span>As Low As</span>
                    <strong>$99/mo</strong>
                  </div>
                </div>

                <div className="offer-grid">
                  <div>Same-day install openings</div>
                  <div>Energy-efficient systems</div>
                  <div>Smart thermostat upgrades</div>
                  <div>Flexible financing plans</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="services" className="section">
          <div className="container">
            <SectionTag>Our Services</SectionTag>
            <h2>Heating and cooling solutions that are built to close.</h2>
            <p className="section-copy">
              Built for homeowners who want speed, clarity, and confidence. Every visit is
              designed to solve the problem and make the next step easy.
            </p>

            <div className="card-grid three">
              {services.map((service, index) => (
                <div className="card service-card" key={service}>
                  <div className="icon-badge">{index + 1}</div>
                  <h3>{service}</h3>
                  <p>
                    Clean workmanship, clear communication, and practical comfort upgrades
                    without the runaround.
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="systems" className="section alt">
          <div className="container">
            <SectionTag>System Options</SectionTag>
            <h2>Good, Better, Best — made easy to understand.</h2>
            <p className="section-copy">
              Position the right system clearly, show the value, and guide homeowners toward
              the most confident choice.
            </p>

            <div className="card-grid three">
              {plans.map((plan) => (
                <div className={plan.featured ? "plan-card featured" : "plan-card"} key={plan.name}>
                  <div className="plan-badge">{plan.badge}</div>
                  <div className="plan-head">
                    <h3>{plan.name}</h3>
                    <div className="plan-price">{plan.price}</div>
                  </div>
                  <p>{plan.description}</p>
                  <div className="feature-list">
                    {plan.features.map((feature) => (
                      <div className="feature-chip" key={feature}>
                        {feature}
                      </div>
                    ))}
                  </div>
                  <CTAButton href="#contact">{`Request ${plan.name}`}</CTAButton>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="financing" className="section">
          <div className="container split">
            <div>
              <SectionTag>Financing Available</SectionTag>
              <h2>Comfort now. Payments that feel manageable.</h2>
              <p className="section-copy">
                Monthly payment framing helps homeowners move forward faster and with more
                confidence.
              </p>
              <div className="card-grid three tight">
                <div className="card metric-card">
                  <strong>$99/mo</strong>
                  <span>Entry monthly option</span>
                </div>
                <div className="card metric-card">
                  <strong>0% OAC</strong>
                  <span>Promotional financing</span>
                </div>
                <div className="card metric-card">
                  <strong>Fast</strong>
                  <span>Application decisions</span>
                </div>
              </div>
            </div>

            <div className="dark-panel">
              <p className="eyebrow">Example Breakdown</p>
              <div className="breakdown-row">
                <span>Better System</span>
                <strong>$9,800</strong>
              </div>
              <div className="breakdown-row">
                <span>Promo Financing</span>
                <strong>0% OAC</strong>
              </div>
              <div className="breakdown-row">
                <span>Estimated Payment</span>
                <strong>$99-$149/mo</strong>
              </div>
            </div>
          </div>
        </section>

        <section className="section dark">
          <div className="container split">
            <div>
              <SectionTag>Before & After</SectionTag>
              <h2>Show the upgrade. Sell the confidence.</h2>
              <p className="section-copy dark-copy">
                This section is designed for real job photos. Swap in your install images to
                instantly increase trust.
              </p>
            </div>
            <div className="before-after">
              <div className="photo-card">
                <div className="photo-placeholder">Before Install Photo</div>
                <h3>Before</h3>
                <p>Older equipment, poor airflow, rising energy bills.</p>
              </div>
              <div className="photo-card highlight">
                <div className="photo-placeholder">After Install Photo</div>
                <h3>After</h3>
                <p>Clean install, better comfort, and improved efficiency.</p>
              </div>
            </div>
          </div>
        </section>

        <section id="reviews" className="section">
          <div className="container">
            <SectionTag>Customer Reviews</SectionTag>
            <h2>Trust that feels immediate.</h2>
            <div className="card-grid three">
              {reviews.map((review) => (
                <div className="card review-card" key={review.name}>
                  <div className="stars">★★★★★</div>
                  <p>"{review.text}"</p>
                  <div className="review-name">{review.name}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="section alt">
          <div className="container split">
            <div className="card large-card">
              <SectionTag>Maintenance Plan</SectionTag>
              <h2>Beach Comfort Club</h2>
              <p className="section-copy">
                Recurring service plans that keep comfort predictable and help homeowners say yes
                to long-term care.
              </p>
              <div className="feature-list two-cols">
                <div className="feature-chip">Priority scheduling</div>
                <div className="feature-chip">Seasonal tune-ups</div>
                <div className="feature-chip">Repair discounts</div>
                <div className="feature-chip">Extended system life</div>
              </div>
            </div>

            <div className="dark-panel">
              <p className="eyebrow">Frequently Asked</p>
              {faqs.map((faq) => (
                <div className="faq-item" key={faq.q}>
                  <strong>{faq.q}</strong>
                  <p>{faq.a}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <SectionTag>Service Areas</SectionTag>
            <h2>City pages built for local SEO.</h2>
            <p className="section-copy">
              These sections are included so you can split them into separate routes later, or
              keep them on one long SEO page until the site grows.
            </p>

            <CityPage city="Irvine" />
            <CityPage city="Newport Beach" />
            <CityPage city="Costa Mesa" />
            <CityPage city="Santa Ana" />
            <CityPage city="Tustin" />
            <CityPage city="Anaheim" />
          </div>
        </section>

        <section id="contact" className="contact-section">
          <div className="container split">
            <div>
              <SectionTag>Ready to Book?</SectionTag>
              <h2>Let’s get your home comfortable again.</h2>
              <p className="section-copy light-copy">
                Use this section as your conversion engine. Connect it to your contact form,
                call tracking number, and review links.
              </p>
              <div className="hero-actions">
                <CTAButton href="tel:+19492873618">Call (949) 287-3618</CTAButton>
                <CTAButton href="mailto:info@beachheatingair.com" secondary>
                  Email Us
                </CTAButton>
              </div>
            </div>

            <div className="contact-card">
              <h3>Request Your Free Estimate</h3>
              <div className="form-mock">Full Name</div>
              <div className="form-mock">Phone Number</div>
              <div className="form-mock">Email Address</div>
              <div className="form-mock">City / Zip Code</div>
              <div className="form-mock message">How can we help?</div>
              <button className="submit-btn">Submit Request</button>
            </div>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="container footer-inner">
          <div>
            <strong>Beach Heating & Air</strong> · Same-day install · Orange County HVAC
          </div>
          <div className="footer-links">
            <a href="#services">Services</a>
            <a href="#systems">Systems</a>
            <a href="#contact">Get Estimate</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
